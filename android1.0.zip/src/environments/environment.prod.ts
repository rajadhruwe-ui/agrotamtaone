export const environment = {
  production: true,
  baseurl:'http://localhost:8000'
};

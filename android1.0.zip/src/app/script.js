function alert() {
    alert("wellcome")
}
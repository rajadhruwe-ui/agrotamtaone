import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loyout',
  templateUrl: './loyout.component.html',
  styleUrls: ['./loyout.component.scss'],
})
export class LoyoutComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}

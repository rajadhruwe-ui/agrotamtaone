import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-field',
  templateUrl: './edit-field.component.html',
  styleUrls: ['./edit-field.component.scss'],
})
export class EditFieldComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}

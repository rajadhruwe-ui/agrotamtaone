import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-farm-manager',
  templateUrl: './farm-manager.component.html',
  styleUrls: ['./farm-manager.component.scss'],
})
export class FarmManagerComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}

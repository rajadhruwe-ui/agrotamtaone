import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-field',
  templateUrl: './add-field.component.html',
  styleUrls: ['./add-field.component.scss'],
})
export class AddFieldComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}

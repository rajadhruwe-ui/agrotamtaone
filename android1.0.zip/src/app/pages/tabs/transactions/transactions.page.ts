import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { LoginPage } from 'src/app/login/login.page';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.page.html',
  styleUrls: ['./transactions.page.scss'],
})
export class TransactionsPage implements OnInit {
  public alertButtons = ['OK'];
  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    
  }
   
  // start
 
  // end 


  // start
 
  
  
}

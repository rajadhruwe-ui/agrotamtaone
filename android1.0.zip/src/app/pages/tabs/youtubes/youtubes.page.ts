import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-youtubes',
  templateUrl: './youtubes.page.html',
  styleUrls: ['./youtubes.page.scss'],
})
export class YoutubesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  




}
from django.urls import path
from .conn import check_db_connection
from .views import *
from . import views


urlpatterns = [
    path('check_db/', check_db_connection, name='check_db'),
    path('users/', UserListAPIView.as_view(), name='user-list'),
    # path('users/<int:id>/', UserListAPIView.as_view(), name='user-update'),
    path('login/', LoginAPIView.as_view(), name='login'),
    path('profile/<int:id>/', ProfileView.as_view(), name='profile'),
]
